import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-pipe-exercise',
  templateUrl: './custom-pipe-exercise.component.html',
  styleUrls: ['./custom-pipe-exercise.component.css']
})
export class CustomPipeExerciseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
