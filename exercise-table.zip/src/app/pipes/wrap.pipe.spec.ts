import { WrapPipe } from './wrap.pipe';

describe('WrapPipe', () => {
  it('create an instance', () => {
    const pipe = new WrapPipe();
    expect(pipe).toBeTruthy();
  });
});
